import { createRequire } from "node:module";
var __require = /* @__PURE__ */ createRequire(import.meta.url);

// src/utils/image-resize.shared.ts
var MAX_IMAGE_WIDTH = 2000;
var MAX_IMAGE_HEIGHT = 2000;
var MAX_IMAGE_BYTES = 5 * 1024 * 1024;
var MAX_IMAGE_INPUT_PIXELS = 25000000;
function mediaTypeForDecodedImageFormat(format) {
  const normalized = format?.trim().toLowerCase();
  switch (normalized) {
    case "jpg":
    case "jpeg":
      return "image/jpeg";
    case "png":
      return "image/png";
    case "gif":
      return "image/gif";
    case "webp":
      return "image/webp";
    default:
      return null;
  }
}
function canonicalizeOutputMediaType(decodedFormat, fallbackMediaType) {
  return mediaTypeForDecodedImageFormat(decodedFormat) ?? fallbackMediaType;
}
function assertImageHasDimensions(width, height, context) {
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) {
    throw new Error(`${context} has invalid dimensions: ${String(width)}x${String(height)}`);
  }
}
function assertImageWithinBounds(width, height, context) {
  assertImageHasDimensions(width, height, context);
  if (width > MAX_IMAGE_WIDTH || height > MAX_IMAGE_HEIGHT) {
    throw new Error(`${context} exceeds ${MAX_IMAGE_WIDTH}x${MAX_IMAGE_HEIGHT}: ${width}x${height}`);
  }
}
function buildResizeResult(buffer, mediaType, width, height, resized) {
  return {
    data: buffer.toString("base64"),
    mediaType,
    width,
    height,
    resized
  };
}

// src/utils/image-resize.sharp.ts
var sharp = (process.platform === "linux" && process.arch === "x64" && process.versions.electron ? await import("@janhapke/sharp-electron") : await import("sharp")).default;
function createSharpInstance(buffer) {
  return sharp(buffer, {
    failOn: "warning",
    limitInputPixels: MAX_IMAGE_INPUT_PIXELS
  });
}
function wrapSharpImageError(error) {
  if (error instanceof Error && error.message.toLowerCase().includes("pixel limit")) {
    return new Error(`Image exceeds the ${MAX_IMAGE_INPUT_PIXELS.toLocaleString()} pixel input limit`);
  }
  return error instanceof Error ? error : new Error(String(error));
}
async function inspectImageBuffer(buffer, context) {
  const metadata = await createSharpInstance(buffer).metadata().catch((error) => {
    throw wrapSharpImageError(error);
  });
  const width = metadata.width ?? 0;
  const height = metadata.height ?? 0;
  assertImageHasDimensions(width, height, context);
  return {
    width,
    height,
    format: metadata.format,
    orientation: metadata.orientation
  };
}
async function buildVerifiedResizeResult(buffer, mediaType, resized, context) {
  const { width, height, format } = await inspectImageBuffer(buffer, context);
  assertImageWithinBounds(width, height, context);
  return buildResizeResult(buffer, canonicalizeOutputMediaType(format, mediaType), width, height, resized);
}
async function compressToFitByteLimit(buffer, currentWidth, currentHeight) {
  if (buffer.length <= MAX_IMAGE_BYTES) {
    return null;
  }
  const qualities = [85, 70, 55, 40];
  for (const quality of qualities) {
    const compressed = await createSharpInstance(buffer).jpeg({ quality }).toBuffer();
    if (compressed.length <= MAX_IMAGE_BYTES) {
      return buildVerifiedResizeResult(compressed, "image/jpeg", true, "compressed image output");
    }
  }
  const scales = [0.75, 0.5, 0.25];
  for (const scale of scales) {
    const scaledWidth = Math.floor(currentWidth * scale);
    const scaledHeight = Math.floor(currentHeight * scale);
    const reduced = await createSharpInstance(buffer).resize(scaledWidth, scaledHeight, {
      fit: "inside",
      withoutEnlargement: true
    }).jpeg({ quality: 70 }).toBuffer();
    if (reduced.length <= MAX_IMAGE_BYTES) {
      return buildVerifiedResizeResult(reduced, "image/jpeg", true, "dimension-reduced image output");
    }
  }
  throw new Error(`Image too large: ${(buffer.length / 1024 / 1024).toFixed(1)}MB exceeds 5MB limit even after compression`);
}
async function resizeImageIfNeeded(buffer, inputMediaType) {
  const sourceMetadata = await inspectImageBuffer(buffer, "source image");
  const normalizedBuffer = sourceMetadata.orientation && sourceMetadata.orientation !== 1 ? await createSharpInstance(buffer).rotate().toBuffer() : buffer;
  const image = createSharpInstance(normalizedBuffer);
  const { width, height, format } = await inspectImageBuffer(normalizedBuffer, "normalized source image");
  const needsResize = width > MAX_IMAGE_WIDTH || height > MAX_IMAGE_HEIGHT;
  const isPassthroughFormat = format === "png" || format === "jpeg";
  if (!needsResize && isPassthroughFormat) {
    const compressed2 = await compressToFitByteLimit(normalizedBuffer, width, height);
    if (compressed2) {
      return compressed2;
    }
    return buildVerifiedResizeResult(normalizedBuffer, inputMediaType, false, "passthrough image output");
  }
  if (needsResize) {
    const resized = image.resize(MAX_IMAGE_WIDTH, MAX_IMAGE_HEIGHT, {
      fit: "inside",
      withoutEnlargement: true
    });
    let outputBuffer2;
    let outputMediaType;
    if (format === "jpeg") {
      outputBuffer2 = await resized.jpeg({ quality: 85 }).toBuffer();
      outputMediaType = "image/jpeg";
    } else {
      outputBuffer2 = await resized.png().toBuffer();
      outputMediaType = "image/png";
    }
    const { width: resizedWidth, height: resizedHeight } = await inspectImageBuffer(outputBuffer2, "resized image output");
    const compressed2 = await compressToFitByteLimit(outputBuffer2, resizedWidth, resizedHeight);
    if (compressed2) {
      return compressed2;
    }
    return buildVerifiedResizeResult(outputBuffer2, outputMediaType, true, "resized image output");
  }
  const outputBuffer = await image.png().toBuffer();
  const compressed = await compressToFitByteLimit(outputBuffer, width, height);
  if (compressed) {
    return compressed;
  }
  return buildVerifiedResizeResult(outputBuffer, "image/png", false, "converted image output");
}

// src/utils/image-resize-worker.ts
async function readInput() {
  const chunks = [];
  for await (const chunk of process.stdin) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}
async function main() {
  const inputMediaType = process.argv[2];
  if (!inputMediaType) {
    throw new Error("Image media type is required");
  }
  const buffer = await readInput();
  const result = await resizeImageIfNeeded(buffer, inputMediaType);
  process.stdout.write(JSON.stringify(result));
}
try {
  await main();
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  process.stderr.write(message);
  process.exitCode = 1;
}

//# debugId=5C3EB104D050543764756E2164756E21
